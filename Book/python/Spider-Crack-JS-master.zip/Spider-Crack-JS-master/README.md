## JS爆破
会每周更新一个网站的JS破解

 欢迎提issue，有能力的都会去爆破

**如果对你有用，请你给个 star**

**本项目仅用于学习交流，切勿用于任何非法用途**

**请遵守本地法律**


### 破解的网站汇合

2019-4-3日更新Last-Event-ID 的cookie 获取

2019-3-18日更新Incapsula-CDN 的一个 cookie 反爬破解

2019-3-18日更新努比亚论坛的cookie 获取 acw_sc__v2 值 
>破解思路详情点击→ [努比亚论坛的cookie 获取 acw_sc__v2 值](https://mp.weixin.qq.com/s/MLjyLP-z8OYBgg48gj-pDA)

2019-3-18日更新pdd的 anti_content 加密参数
>破解思路详情点击→ [拼多多的 anti_content 加密参数](https://sergiojune.com/2019/03/26/pinduoduo_anti_content/)

2019-3-11日更新某瓣读书搜索页的window.__DATA__的解密
>破解思路详情点击→ [豆瓣读书搜索页的window.__DATA__的解密](https://mp.weixin.qq.com/s/2mpu_oY2-M0wcLvf1eU7Sw)



2019-3-5日更新的某乎的最新版登陆
>破解思路详情点击→ [破解知乎登陆formdata思路](https://mp.weixin.qq.com/s?__biz=MzU0NzY0NzQyNw==&mid=2247484776&idx=1&sn=875c2decbf41b215ae2d564432ea89e6&chksm=fb4a7fc4cc3df6d2046eaaabed115e18daa4208eefccc0e86e3b02b073432e231cf0bd87cdad&xtrack=1&scene=0&subscene=131&clicktime=1550805130&ascene=7&devicetype=android-28&version=27000339&nettype=3gnet&abtest_cookie=BAABAAoACwATABQABAAjlx4AV5keAJuZHgC%2BmR4AAAA%3D&lang=zh_CN&pass_ticket=YqYmHd0L6YmpuL4aq8hBnCoz0L7z4HuCi%2Bz%2F3%2FMWqK0gkaAAXWiQ3%2BEzUhNZc%2BmD&wx_header=1)


### 想看更多文章扫码关注公众号！
![公众号日常学python](https://user-gold-cdn.xitu.io/2019/2/22/169130346d926dc7?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)
