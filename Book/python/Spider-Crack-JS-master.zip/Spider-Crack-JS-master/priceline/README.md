### Incapsula-CDN 的一个cookie反爬

网址为 **https://www.priceline.com.au**

需要获取的 cookie 为：**___utmvc**

### 文件说明
1. get_cookie.js: 获取 cookie 为 ___utmvc
2. priceline.py: 通过 python 获取 网页 的内容

### 参数说明
priceline.py 文件内都获取 js 里面所需要的 参数了，直接运行 priceline.py 文件即可
详细说明有空再更新

### 想看更多文章扫码关注公众号！
![公众号日常学python](https://user-gold-cdn.xitu.io/2019/2/22/169130346d926dc7?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)