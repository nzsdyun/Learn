### 文件说明
1. **get_anticontent.js**: 获取拼多多搜索页下一页的加密参数 anticontent
2. **pinduouduo.py**: 通过python执行上面的 js 获取拼多多的搜索页以及下一页的数据

#### get_anticontent.js 参数说明
只需要传一个 搜索页的 url 即可，比如 **http://yangkeduo.com/search_result.html?search_key=%E6%83%85%E4%BE%A3%E8%A1%A3%E6%9C%8D**

**注意：search_key 为搜索关键字，需要 url 编码**

##### 本项目仅用于学习交流，切勿用于任何非法用途

### 想看更多文章扫码关注公众号！
![公众号日常学python](https://user-gold-cdn.xitu.io/2019/2/22/169130346d926dc7?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)