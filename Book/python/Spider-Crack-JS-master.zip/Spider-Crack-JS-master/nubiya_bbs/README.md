### 努比亚论坛的 html 获取
#### url 为：https://bbs.nubia.cn/
#### 这是个 cookie 的 反爬
需要获取 cookie 键为 **acw_sc__v2** 的值才能获得网页的 html

这里有一个小bug，就是有时候获取不到，多运行几次就可以了，问题不大

### 想看更多文章扫码关注公众号！
![公众号日常学python](https://user-gold-cdn.xitu.io/2019/2/22/169130346d926dc7?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)