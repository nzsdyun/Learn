### 网站url：https://www.17track.net/zh-cn

### 文件相关作用
* 17track.js：获取Last-Event-ID这个cookie的值
* track.py: 使用python来运行获取运单详情

17track.js 文件中需要传一个参数，为单号的 formdata，具体格式里面文件的最后一行有样板。

#### 扫码关注公众号查看更多文章
![公众号日常学python](https://user-gold-cdn.xitu.io/2019/2/22/169130346d926dc7?imageView2/0/w/1280/h/960/format/webp/ignore-error/1)
