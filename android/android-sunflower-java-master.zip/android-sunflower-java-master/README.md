Sunflower - Java
=========================
Java version of [Google's Sunflower app](https://github.com/googlesamples/android-sunflower), which is coded in Kotlin.
