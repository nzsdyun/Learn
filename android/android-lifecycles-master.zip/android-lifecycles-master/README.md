# Android Lifecycle-aware Components Codelab

Please follow along the codelab steps [here](https://codelabs.developers.google.com/codelabs/android-lifecycles/).

# Filing issues

If you find errors in the codelab steps or the code, please file them [here](https://github.com/googlecodelabs/android-lifecycles/issues/new)
